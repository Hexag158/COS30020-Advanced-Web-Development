<!DOCTYPE html>
<html lang="en">
<head>
<title>Home Page - Job Vacancy Posting System</title>
<meta charset="utf-8">
<meta name="description" content="Web development">
<meta name="keywords" content="HTML, CSS, JavaScript">
<meta name="Nghia" content="103806269">
</head>
<body>
    <h1>Job Vacancy Posting System</h1>
    <p>Name: Nguyen Minh Nghia</br>
    Student ID: 103806269</br>
    Email: 103806269@student.swin.edu.au</p>

    <p>I declare that this assignment is my individual work. I have not worked collaboratively nor have I <br>
    copied fronm any other student's work or from any other source</p>
    
    <p>
    <a href="postjobform.php">Post a job</a><br>
    <a href="searchjobform.php">Search for Job</a><br>
    <a href="about.php">About Page</a>
    </p>
</body>
</html>