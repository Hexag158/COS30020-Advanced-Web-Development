<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content="Web Programming :: Lab 2" />
<meta name="keywords" content="Web,programming" />
<meta name="Nghia" content="103806269">
</head>
<body>
<h1>Lab 03 Task 3 - Prime Number</h1>
<form action="primenumber.php" method="get">  
Enter a number: <input type="text" name="primenumber"/>  
<input type="submit" value="Check"/>  
</form>  
</body>
</html>