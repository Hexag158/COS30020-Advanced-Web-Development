<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="description" content="Web application development" />
<meta name="keywords" content="PHP" />
<meta name="author" content="Your Name" />
<title>TITLE</title>
</head>
<body>
    <h1>Welcome to the VIP Member Home Page</h1>
    <ul>
        <li><a href="member_add_form.php">Add New Member Form</a></li>
        <li><a href="member_display.php">Display All Members Page</a></li>
        <li><a href="member_search.php">Search Member Page</a></li>
    </ul>
</body>
</html>