<?php
$host = "feenix-mariadb.swin.edu.au";
$user = "s103806269"; // your user name
$pswd = "150803"; // your password d(date of birth – ddmmyy)
$dbnm = "s103806269_db"; // your database
$tablename = "hitcounter";
?>