<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="utf-8" />
 <meta name="description" content="Web application development" />
 <meta name="keywords" content="PHP" />
 <meta name="author" content="Nguyen Minh Nghia - 103806269" />
</head>
<body>
    <h1>Web Programming Form - Lab 4 - TASK 1</h1>
    <form action = "strprocess.php" method = "post" >
    Enter a string: <input type="text" name="str"/>  
    <input type="submit" value="Check"/>  
</form>
</body>
</html>

