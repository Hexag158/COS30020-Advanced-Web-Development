<!DOCTYPE html>
<html lang="en">
<head>
<title>Home Page - My Friends System</title>
<meta charset="utf-8">
<meta name="description" content="Web development">
<meta name="keywords" content="HTML, CSS, JavaScript">
<meta name="Nghia" content="103806269">
</head>
<body>
    <h1>My Friends System - About Page</h1>
    <h2>What tasks that i have not attempted or not completed?</h2>
    <ul>
        <li>The only tasks that i have not attempted is adding CSS used for colours and styles</li>
    </ul>

    <h2>What special features have i done, or attempted, in creating the site that you should know about?</h2>
    <ul>
        <li>Basically i have finished all the required features, I have done the login and signin function </br>
        as well as finished the pagination features and mutual friends</li>
    </ul>

    <h2>Which parts did i have trouble with?</h2>
    <ul>
        <li>The two last features were a little bit challenging to me, it took me 2 days of working on those </br>
        and i felt so proud when i finished it.</li>
    </ul>

    <h2>What would i like to do better next time?</h2>
    <ul>
        <li>If there are something that i want to do better, it must be code optimizing.</li>
    </ul>

    <h2>Links to Other Pages:</h2>
    <ul>
        <li><a href="friendlist.php">Friend List </a></li>
        <li><a href="friendadd.php">Add Friends </a></li>
        <li><a href="index.php">Home Page </a></li>
    </ul>

    <h2>What discussion points did i participated on in the units discussion board for Assignment 2?</h2>
    <ul>
        <li>I joined the discussion about using foreach loop outside of an object to loop through the array inside that object </br>
        Here is the screenshots: </br>
        <?php echo "<img src='screenshot.jpg' width=800' >"; ?> </li>
    </ul>
</body>
</html>