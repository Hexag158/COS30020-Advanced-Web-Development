<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="description" content="Web application development" />
<meta name="keywords" content="PHP" />
<meta name="NGUYEN MINH NGHIA" content="103806269" />
<title>WEB-DEV LAB 5 TASK 1</title>
</head>
<body>
<h1>Web Programming Form - Lab 5 - TASK 1</h1>
<form action="shoppingsave.php" method="POST">
    <label for="item-name">Item Name:</label>
    <input type="text" id="item-name" name="item-name"/><br>
    <label for="quantity">Quantity:</label>
    <input type="number" id="quantity" name="quantity" /><br>
    <input type="submit" value="Submit" />
</form>
</body>
</html>